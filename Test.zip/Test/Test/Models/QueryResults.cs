﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Test.Models
{
    public class QueryResults
    {
        public int Value { get; set; } // change to int if Users.Id has integer value
        public string Text { get; set; }

    }
}